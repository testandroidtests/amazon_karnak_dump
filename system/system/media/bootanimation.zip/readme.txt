Part01 being a single repeated black frame is intentional, to delay display of animation till mode change completes.
Part02 is the beginning of the sequence before the loop portion
Part03 is intended to loop for as long as needed to load Home 
Part04 is the exit motion that plays at the end of the final loop before transitioning directly to Tablet Home screen 

See TabletBoot.mp4 for reference 